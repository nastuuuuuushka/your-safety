$(document).ready(function(){
  console.log(1);
   $('.slider').slick({
     dots:true,
     arrows:true,
     autoplay: false,
     autoplaySpeed: 2000
   });
 });

